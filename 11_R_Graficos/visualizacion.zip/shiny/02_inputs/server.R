# Utilizar tres inputs del UI con la base de datos gapminder
shinyServer(function(input, output) {
  
})
